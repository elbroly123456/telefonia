document.getElementById("eliminarUsuario").addEventListener("click", async () => {
  const usuarioId = usuarioSelect.value;
  if (!usuarioId) {
    alert("Selecciona un usuario primero.");
    return;
  }

  if (!confirm("⚠️ ¿Seguro que quieres eliminar este usuario y sus llamadas?")) return;

  const res = await fetch(`http://localhost:5000/usuarios/${usuarioId}`, {
    method: "DELETE"
  });

  if (res.ok) {
    alert("✅ Usuario eliminado correctamente.");
    usuarioSelect.innerHTML = '<option value="">-- Selecciona un usuario --</option>'; // reinicia select
    tablaBody.innerHTML = ""; // limpia la tabla
    cargarUsuarios(); // vuelve a cargar lista
  } else {
    alert("❌ Error al eliminar usuario.");
  }
});
