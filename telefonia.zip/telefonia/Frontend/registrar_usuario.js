// Datos de prefijos y rangos
const prefijos_fijos = { 
  "operadora": "fijo",
  "rangos": [
    {"Departamento": "Carazo", "linea1": 243},
    {"Departamento": "Managua", "linea1": 22},
    {"Departamento": "Masaya", "linea1": 252},
    {"Departamento": "Granada", "linea1": 255},
    {"Departamento": "Rivas", "linea1": 246},
    {"Departamento": "León", "linea1": 2311},
    {"Departamento": "Chinandega", "linea1": 2341},
    {"Departamento": "Boaco", "linea1": 254},
    {"Departamento": "Estelí", "linea1": 271},
    {"Departamento": "Jinotega", "linea1": 273},
    {"Departamento": "Matagalpa", "linea1": 272},
    {"Departamento": "Nueva_Segovia", "linea1": 279},
    {"Departamento": "Madriz", "linea1": 277},
    {"Departamento": "Chontales", "linea1": 254},
    {"Departamento": "Río_San_Juan", "linea1": 278},
    {"Departamento": "Atlántico_Sur", "linea1": 257},
    {"Departamento": "Atlántico_Norte", "linea1": 258}
  ]
};

const prefijos_claro = {
  "operadora": "claro",
  "rangos": [
    {"inicio": 5740 , "fin": 5749},
    {"inicio": 5780 , "fin": 5789},
    {"inicio": 5800 , "fin": 5809},
    {"inicio": 8330 , "fin": 8339},
    {"inicio": 8350 , "fin": 8369},
    {"inicio": 8400 , "fin": 8449},
    {"inicio": 8490 , "fin": 8499},
    {"inicio": 8500 , "fin": 8549},
    {"inicio": 8600 , "fin": 8669},
    {"inicio": 8690 , "fin": 8699},
    {"inicio": 8700 , "fin": 8749},
    {"inicio": 8820 , "fin": 8859},
    {"inicio": 8900 , "fin": 8949}
  ]
};

const prefijos_tigo = {
  "operadora": "tigo",
  "rangos": [
    {"inicio": 7710 , "fin": 7719},
    {"inicio": 7750 , "fin": 7759},
    {"inicio": 7870 , "fin": 7879},
    {"inicio": 8150 , "fin": 8159},
    {"inicio": 8260 , "fin": 8269},
    {"inicio": 8320 , "fin": 8329},
    {"inicio": 8370 , "fin": 8399},
    {"inicio": 8450 , "fin": 8489},
    {"inicio": 8550 , "fin": 8559},
    {"inicio": 8560 , "fin": 8569},
    {"inicio": 8590 , "fin": 8599},
    {"inicio": 8670 , "fin": 8689},
    {"inicio": 8750 , "fin": 8779},
    {"inicio": 8800 , "fin": 8819},
    {"inicio": 8860 , "fin": 8899},
    {"inicio": 8950 , "fin": 8979},
    {"inicio": 8990 , "fin": 8999}
  ]
};

// Elementos del DOM
const departamento = document.getElementById("departamento");
const region = document.getElementById("region");
const numeroInput = document.getElementById("numeroUsuario");
const operadoraSelect = document.getElementById("operadoraUsuario");
const mensaje = document.getElementById("mensajeUsuario");

// Actualizar región y bloqueos según departamento
departamento.addEventListener("change", () => {
  const dep = departamento.value;
  numeroInput.value = "";
  mensaje.textContent = "";

  if(dep === "Ninguna") {
    region.value = "Indefinido";
    operadoraSelect.disabled = true; // será automática
    numeroInput.placeholder = "Ej: 57401234 (Claro/Tigo)";
  } else {
    const prefijo = prefijos_fijos.rangos.find(r => r.Departamento === dep)?.linea1;
    region.value = dep ? getRegion(dep) : "";
    operadoraSelect.value = "fijo";
    operadoraSelect.disabled = true;
    numeroInput.placeholder = `Comienza con ${prefijo}`;
  }
});

// Función para obtener región
function getRegion(dep) {
  if(["Managua","Carazo","Masaya","Granada","Rivas"].includes(dep)) return "Pacífico";
  if(["Chontales","Boaco","Matagalpa","Jinotega"].includes(dep)) return "Central";
  if(["León","Chinandega","Estelí","Nueva_Segovia","Madriz","Río_San_Juan","Atlántico_Sur","Atlántico_Norte"].includes(dep)) return "Norte";
  return "Indefinido";
}

// Validación de número al escribir
numeroInput.addEventListener("input", () => {
  const dep = departamento.value;
  let val = numeroInput.value.trim();

  if(dep !== "Ninguna") {
    // Bloqueo para prefijo fijo
    const prefijo = prefijos_fijos.rangos.find(r => r.Departamento === dep)?.linea1.toString();
    if(!val.startsWith(prefijo)) {
      numeroInput.value = prefijo;
    }
  } else {
    // Móviles: asignar operadora según primeros 4 dígitos
    if(val.length >= 4) {
      const prefijo4 = parseInt(val.slice(0,4));
      if(prefijos_claro.rangos.some(r => prefijo4 >= r.inicio && prefijo4 <= r.fin)) {
        operadoraSelect.value = "claro";
      } else if(prefijos_tigo.rangos.some(r => prefijo4 >= r.inicio && prefijo4 <= r.fin)) {
        operadoraSelect.value = "tigo";
      } else {
        operadoraSelect.value = "";
      }
    } else {
      operadoraSelect.value = "";
    }
  }
});

// Enviar formulario
document.getElementById("registrarUsuario").addEventListener("click", () => {
  const nombre = document.getElementById("nombre").value.trim();
  const numero = numeroInput.value.trim();
  const regionVal = region.value;
  const dep = departamento.value;
  const operadora = operadoraSelect.value;

  if(!nombre || !numero || !dep) {
    mensaje.textContent = "⚠️ Completa todos los campos obligatorios.";
    mensaje.style.color = "red";
    return;
  }

  fetch("http://127.0.0.1:5000/registrar_usuario", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nombre, numero, region: regionVal, departamento: dep, operadora })
  })
  .then(res => res.json())
  .then(data => {
    mensaje.textContent = data.mensaje;
    mensaje.style.color = data.status === "ok" ? "green" : "red";
    if(data.status === "ok") {
      document.getElementById("nombre").value = "";
      numeroInput.value = "";
      departamento.value = "";
      region.value = "";
      operadoraSelect.value = "fijo";
    }
  })
  .catch(err => console.error(err));
});
