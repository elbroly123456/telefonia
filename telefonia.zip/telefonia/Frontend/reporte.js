const usuarioSelect = document.getElementById("usuarioSelect");
const tablaBody = document.querySelector("#tabla tbody");
let llamadasUsuario = [];

// ==================== Obtener usuarios del backend ====================
async function cargarUsuarios() {
  const res = await fetch("http://localhost:5000/usuarios");
  const usuarios = await res.json();

  usuarios.forEach(u => {
    const option = document.createElement("option");
    option.value = u.usuario_id;
    option.textContent = `${u.nombre} (${u.numero})`;
    usuarioSelect.appendChild(option);
  });
}

// ==================== Cargar llamadas del usuario seleccionado ====================
usuarioSelect.addEventListener("change", async () => {
  const usuarioId = usuarioSelect.value;
  if (!usuarioId) {
    tablaBody.innerHTML = "";
    return;
  }

  const res = await fetch(`http://localhost:5000/llamadas/${usuarioId}`);
  llamadasUsuario = await res.json();

  tablaBody.innerHTML = "";
  llamadasUsuario.forEach(l => {
    const fila = `<tr>
      <td>${l.numero_llamado}</td>
      <td>${l.duracion_s}s</td>
      <td>${l.operadora_origen} → ${l.operadora_destino}</td>
      <td>${l.troncal}</td>
      <td>${l.costo} C$</td>
    </tr>`;
    tablaBody.innerHTML += fila;
  });
});

// ==================== Generar PDF tipo factura ====================
document.getElementById("generarPDF").addEventListener("click", () => {
  if (!llamadasUsuario.length) {
    alert("Selecciona un usuario con llamadas.");
    return;
  }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const usuarioTexto = usuarioSelect.options[usuarioSelect.selectedIndex].text;
  const fechaActual = new Date().toLocaleDateString();

  doc.setFontSize(18);
  doc.text("FACTURA DE LLAMADAS", 14, 20);

  doc.setFontSize(12);
  doc.text(`Usuario: ${usuarioTexto}`, 14, 30);
  doc.text(`Fecha: ${fechaActual}`, 14, 37);

  // Encabezado tabla
  let y = 50;
  doc.setFontSize(12);
  doc.text("N° Llamado", 10, y);
  doc.text("Duración", 42, y);
  doc.text("Operadora_destino", 80, y);
  doc.text("Troncal", 130, y);
  doc.text("Costo (C$)", 175, y);
  y += 6;

  let totalCosto = 0;
  llamadasUsuario.forEach((l, index) => {
    doc.text(`${l.numero_llamado}`, 14, y);
    doc.text(`${l.duracion_s}s`, 46, y);
    doc.text(`${l.operadora_destino}`, 83, y);
    doc.text(`${l.troncal}`, 138, y);
    doc.text(`${l.costo.toFixed(2)}`, 177, y);
    totalCosto += parseFloat(l.costo);
    y += 6;

    // Salto de página si se llena
    if (y > 280) {
      doc.addPage();
      y = 20;
    }
  });

  // Total al final
  y += 6;
  doc.setFontSize(10);
  doc.text(`TOTAL C$ : ${totalCosto.toFixed(2)}`, 140, y);

  // Guardar PDF
  doc.save(`Factura_${usuarioTexto.replace(/\s+/g, "_")}.pdf`);
});

// ==================== Inicializar ====================
cargarUsuarios();
