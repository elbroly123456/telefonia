// ================= Variables globales =================
let timer = null;
let segundos = 0;
let registros = JSON.parse(localStorage.getItem("registros")) || [];

// ================= Tarifas en USD por segundo =================
const tarifasUSD = {
  local: {
    "claro-claro": 0.016,
    "tigo-tigo": 0.016,
    "claro-tigo": 0.025,
    "tigo-claro": 0.028,
    "fijo-fijo": 0.0083,
    "fijo-claro": 0.116,
    "fijo-tigo": 0.116,
    "tigo-fijo": 0.05,
    "claro-fijo": 0.05
  },
  interlocal: {
    "claro-claro": 0.040,
    "tigo-tigo": 0.040,
    "claro-tigo": 0.01,
    "tigo-claro": 0.01,
    "fijo-fijo": 0.01,
    "fijo-claro": 0.1,
    "fijo-tigo": 0.1,
    "tigo-fijo": 0.01,
    "claro-fijo": 0.01
  },
  internacional: {
    "claro-claro": 0.10,
    "tigo-tigo": 0.10,
    "claro-tigo": 0.20,
    "tigo-claro": 0.20,
    "fijo-fijo": 0.15,
    "fijo-claro": 0.30,
    "fijo-tigo": 0.30,
    "tigo-fijo": 0.28,
    "claro-fijo": 0.28
  }
};


// ================= Prefijos fijos =================
const prefijos_fijos = {
  "operadora": "fijo",
  "rangos": [
    {"Departamento": "Carazo", "linea1": 243, "linea2": 24222, "latitud": 11.85, "longitud": -86.20},
    {"Departamento": "Managua", "linea1": 22, "linea2": 253, "latitud": 12.15, "longitud": -86.27},
    {"Departamento": "Masaya", "linea1": 252, "linea2": 244, "latitud": 11.97, "longitud": -86.10},
    {"Departamento": "Granada", "linea1": 255, "linea2": 24522, "latitud": 11.93, "longitud": -85.96},
    {"Departamento": "Rivas", "linea1": 246, "linea2": 24682, "latitud": 11.43, "longitud": -85.83},
    {"Departamento": "León", "linea1": 2311, "linea2": 0, "latitud": 12.43, "longitud": -86.88},
    {"Departamento": "Chinandega", "linea1": 2341, "linea2": 0, "latitud": 12.62, "longitud": -87.13},
    {"Departamento": "Boaco", "linea1": 254, "linea2": 0, "latitud": 12.47, "longitud": -85.67},
    {"Departamento": "Estelí", "linea1": 271, "linea2": 0, "latitud": 13.08, "longitud": -86.35},
    {"Departamento": "Jinotega", "linea1": 273, "linea2": 0, "latitud": 13.08, "longitud": -86.00},
    {"Departamento": "Matagalpa", "linea1": 272, "linea2": 0, "latitud": 12.92, "longitud": -85.92},
    {"Departamento": "Nueva_Segovia", "linea1": 279, "linea2": 0, "latitud": 13.63, "longitud": -86.48},
    {"Departamento": "Madriz", "linea1": 277, "linea2": 0, "latitud": 13.48, "longitud": -86.58},
    {"Departamento": "Chontales", "linea1": 254, "linea2": 0, "latitud": 12.08, "longitud": -85.40},
    {"Departamento": "Río_San_Juan", "linea1": 278, "linea2": 0, "latitud": 11.13, "longitud": -84.78},
    {"Departamento": "Atlántico_Sur", "linea1": 257, "linea2": 0, "latitud": 12.00, "longitud": -83.75},
    {"Departamento": "Atlántico_Norte", "linea1": 258, "linea2": 0, "latitud": 14.05, "longitud": -83.38}
  ]
};

// ================= Funciones comunes =================
function formatTime(segundos) {
  let h = String(Math.floor(segundos / 3600)).padStart(2, "0");
  let m = String(Math.floor((segundos % 3600) / 60)).padStart(2, "0");
  let s = String(segundos % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

// Calcular costo en C$
function calcularCosto(tipo, operadoraOrigen, operadoraDestino, duracion) {
  const key = `${operadoraOrigen}-${operadoraDestino}`.toLowerCase();
  const tarifaUSD = tarifasUSD[tipo]?.[key] ?? 0.10;
  return parseFloat((duracion * tarifaUSD * tipoCambio).toFixed(2));
}

// ================= Funciones de reporte =================
function cargarTabla() {
  const tabla = document.querySelector("#tabla tbody");
  if (!tabla) return;

  tabla.innerHTML = "";
  registros.forEach(r => {
    tabla.innerHTML += `<tr>
      <td>${r.cliente}</td>
      <td>${r.duracion}</td>
      <td>${r.operadora}</td>
      <td>${r.troncal}</td>
      <td>${r.costo} C$</td>
    </tr>`;
  });
}

// ================= Limpiar tabla =================
function limpiarTabla() {
  const limpiarBtn = document.getElementById("limpiar");
  if (!limpiarBtn) return;

  limpiarBtn.addEventListener("click", () => {
    const tablaBody = document.querySelector("#tabla tbody");
    if (tablaBody) tablaBody.innerHTML = "";
    registros = [];
    localStorage.removeItem("registros");
    alert("✅ Tabla limpiada correctamente.");
  });
}


// ================= Centrales Regionales =================
const centrales = [
  {
    id: "C1",
    nombre: "Troncal Managua",
    descripcion: "Troncal principal",
    troncal: "Central Regional del Pacífico",
    principal: true,
    coordenadas: { lat: 12.1364, lon: -86.2514 }
  },
  {
    id: "C2",
    nombre: "Troncal Matagalpa",
    descripcion: "Central Regional Central",
    troncal: "Troncal-Matagalpa",
    principal: false,
    coordenadas: { lat: 12.9259, lon: -85.9175 }
  },
  {
    id: "C3",
    nombre: "Troncal El Rama",
    descripcion: "Central Regional Norte (Caribe)",
    troncal: "Troncal-ElRama",
    principal: false,
    coordenadas: { lat: 12.1596, lon: -84.2199 }
  }
];

// ================= Íconos para centrales =================
const iconCentralPrincipal = L.icon({
  iconUrl: "torre2.png", //ícono
  iconSize: [80, 80],
  iconAnchor: [20, 40],
  popupAnchor: [0, -35]
});

const iconCentralSecundaria = L.icon({
  iconUrl: "torre2.png", //ícono
  iconSize: [75, 75],
  iconAnchor: [17, 34],
  popupAnchor: [0, -30]
});

// ================= Inicializar mapa y llamadas =================
function inicializarMapaYLlamadas() {
  const mapDiv = document.getElementById("map");
  if (!mapDiv) return;

  const map = L.map('map').setView([12.8654, -85.2072], 7);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

    // Dibujar todas las centrales en el mapa
  centrales.forEach(c => {
  const icono = c.principal ? iconCentralPrincipal : iconCentralSecundaria;
  L.marker([c.coordenadas.lat, c.coordenadas.lon], { icon: icono })
    .addTo(map)
    .bindPopup(`<b>${c.nombre}</b><br>Troncal: ${c.troncal}`);
  });


  const iniciarBtn = document.getElementById("iniciar");
  const colgarBtn = document.getElementById("colgar");
  const contador = document.getElementById("contador");
  const estado = document.getElementById("estado");
  const troncal = document.getElementById("troncal");
  const numeroInput = document.getElementById("numero");
  const operadoraOrigenInput = document.getElementById("operadoraOrigen");
  const operadoraDestinoInput = document.getElementById("operadoraDestino");

  const errorMsg = document.createElement("p");
  errorMsg.style.color = "red";
  errorMsg.style.fontSize = "14px";
  errorMsg.style.margin = "4px 0 0 0";
  numeroInput.insertAdjacentElement("afterend", errorMsg);

  function buscarTroncal(numero) {
    for (let r of prefijos_fijos.rangos) {
      if (numero.startsWith(String(r.linea1))) {
        return { depto: r.Departamento, coords: [r.latitud, r.longitud] };
      }
    }
    return { depto: "Desconocido", coords: [12.8654, -85.2072] };
  }

  iniciarBtn?.addEventListener("click", () => {
    let numero = numeroInput.value.trim();
    if (!/^\d{8}$/.test(numero)) {
      errorMsg.textContent = "⚠️ Ingresa un número válido de 8 dígitos.";
      return;
    }

    errorMsg.textContent = "";
    segundos = 0;
    estado.innerText = "Estado: En llamada...";
    iniciarBtn.disabled = true;
    colgarBtn.disabled = false;

    const dataTroncal = buscarTroncal(numero);
    troncal.innerText = `Troncal: ${dataTroncal.depto}`;

    L.marker(dataTroncal.coords).addTo(map).bindPopup(`Troncal ${dataTroncal.depto}`).openPopup();
    map.setView(dataTroncal.coords, 9);

    timer = setInterval(() => {
      segundos++;
      contador.innerText = formatTime(segundos);
    }, 1000);
  });

  colgarBtn?.addEventListener("click", () => {
    clearInterval(timer);
    iniciarBtn.disabled = false;
    colgarBtn.disabled = true;
    estado.innerText = "Estado: Finalizada";

    const numero = numeroInput.value || "Cliente sin nombre";
    const tipo = document.getElementById("tipo").value;
    const operadoraOrigen = operadoraOrigenInput.value.toLowerCase();
    const operadoraDestino = operadoraDestinoInput.value.toLowerCase();
    const troncalText = troncal.innerText.replace("Troncal: ", "");

    const costoC$ = calcularCosto(tipo, operadoraOrigen, operadoraDestino, segundos);

    const registro = {
      cliente: numero,
      duracion: formatTime(segundos),
      operadora: `${operadoraOrigen} → ${operadoraDestino}`,
      troncal: troncalText,
      costo: costoC$
    };

    // ==================== TRAZAR LÍNEA ====================
    const origen = buscarTroncal(numero);
    const destino = buscarTroncal(numero); // Aquí puedes ajustar según lógica de destino real
    if (origen && destino) {
      L.polyline([origen.coords, destino.coords], { color: "red" }).addTo(map);
    }

    // Guardar en localStorage
    registros.push(registro);
    localStorage.setItem("registros", JSON.stringify(registros));
    cargarTabla();

    // Enviar al backend Flask
    fetch("http://localhost:5000/procesar_llamada", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        numero: numero,
        duracion: segundos,
        tipo: tipo,
        operadora_origen: operadoraOrigen,
        operadora_destino: operadoraDestino,
        troncal: troncalText,
        costo: costoC$,
        origen_lat: origen.coords[0],
        origen_lng: origen.coords[1],
        destino_lat: destino.coords[0],
        destino_lng: destino.coords[1]
      })
    })
    .then(res => res.json())
    .then(data => console.log("✅ Registro guardado:", data))
    .catch(err => console.error("❌ Error al guardar:", err));
  });
}

// ================= Ejecutar =================
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("map")) inicializarMapaYLlamadas();
  if (document.getElementById("tabla")) {
    cargarTabla();
    limpiarTabla();
  }
});