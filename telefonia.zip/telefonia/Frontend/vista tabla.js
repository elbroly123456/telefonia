function cargarTabla() {
  let registros = JSON.parse(localStorage.getItem("registros")) || [];
  let tbody = document.querySelector("#tabla tbody");
  let total = 0;

  tbody.innerHTML = "";

  registros.forEach(r => {
    let fila = `<tr>
      <td>${r.cliente}</td>
      <td>${r.duracion}</td>
      <td>${r.operadora}</td>
      <td>${r.troncal}</td>
      <td>${r.costo}</td>
    </tr>`;
    tbody.innerHTML += fila;
    total += parseFloat(r.costo);
  });

  document.getElementById("total").textContent = total.toFixed(2);
}

// Ejecutar al cargar la página
document.addEventListener("DOMContentLoaded", cargarTabla);


function cargarTabla() {
  let registros = JSON.parse(localStorage.getItem("registros")) || [];
  let tbody = document.querySelector("#tabla tbody");
  let total = 0;

  tbody.innerHTML = "";

  registros.forEach(r => {
    let fila = `<tr>
      <td>${r.cliente}</td>
      <td>${r.duracion}</td>
      <td>${r.operadora}</td>
      <td>${r.troncal}</td>
      <td>${r.costo}</td>
    </tr>`;
    tbody.innerHTML += fila;
    total += parseFloat(r.costo);
  });

  document.getElementById("total").textContent = total.toFixed(2);
}

// Ejecutar al cargar la página
window.onload = cargarTabla;
