import math

# ================= Prefijos y tarifas =====================
prefijos_claro = {
    "operadora": "claro",
    "rangos": [
        {"inicio": 5740 , "fin": 5749},
        {"inicio": 5780 , "fin": 5789},
        {"inicio": 5800 , "fin": 5809},
        {"inicio": 8330 , "fin": 8339},
        {"inicio": 8350 , "fin": 8369},
        {"inicio": 8400 , "fin": 8449},
        {"inicio": 8490 , "fin": 8499},
        {"inicio": 8500 , "fin": 8549},
        {"inicio": 8600 , "fin": 8669},
        {"inicio": 8690 , "fin": 8699},
        {"inicio": 8700 , "fin": 8749},
        {"inicio": 8820 , "fin": 8859},
        {"inicio": 8900 , "fin": 8949}
    ]
}

prefijos_tigo = {
    "operadora": "tigo",
    "rangos": [
        {"inicio": 7710 , "fin": 7719},
        {"inicio": 7750 , "fin": 7759},
        {"inicio": 7870 , "fin": 7879},
        {"inicio": 8150 , "fin": 8159},
        {"inicio": 8260 , "fin": 8269},
        {"inicio": 8320 , "fin": 8329},
        {"inicio": 8370 , "fin": 8399},
        {"inicio": 8450 , "fin": 8489},
        {"inicio": 8550 , "fin": 8559},
        {"inicio": 8590 , "fin": 8599},
        {"inicio": 8670 , "fin": 8689},
        {"inicio": 8750 , "fin": 8779},
        {"inicio": 8800 , "fin": 8819},
        {"inicio": 8860 , "fin": 8899},
        {"inicio": 8950 , "fin": 8979},
        {"inicio": 8990 , "fin": 8999}
    ]
}

prefijos_fijos = {
    "operadora": "fijo",
    "rangos": [
        {"Departamento": "Carazo", "linea1": 243, "linea2": 24222, "latitud": 11.85, "longitud": -86.20},
        {"Departamento": "Managua", "linea1": 22, "linea2": 253, "latitud": 12.15, "longitud": -86.27},
        {"Departamento": "Masaya", "linea1": 252, "linea2": 244, "latitud": 11.97, "longitud": -86.10},
        {"Departamento": "Granada", "linea1": 255, "linea2": 24522, "latitud": 11.93, "longitud": -85.96},
        {"Departamento": "Rivas", "linea1": 246, "linea2": 24682, "latitud": 11.43, "longitud": -85.83},
        {"Departamento": "León", "linea1": 2311, "linea2": 0, "latitud": 12.43, "longitud": -86.88},
        {"Departamento": "Chinandega", "linea1": 2341, "linea2": 0, "latitud": 12.62, "longitud": -87.13},
        {"Departamento": "Boaco", "linea1": 254, "linea2": 0, "latitud": 12.47, "longitud": -85.67},
        {"Departamento": "Estelí", "linea1": 271, "linea2": 0, "latitud": 13.08, "longitud": -86.35},
        {"Departamento": "Jinotega", "linea1": 273, "linea2": 0, "latitud": 13.08, "longitud": -86.00},
        {"Departamento": "Matagalpa", "linea1": 272, "linea2": 0, "latitud": 12.92, "longitud": -85.92},
        {"Departamento": "Nueva_Segovia", "linea1": 279, "linea2": 0, "latitud": 13.63, "longitud": -86.48},
        {"Departamento": "Madriz", "linea1": 277, "linea2": 0, "latitud": 13.48, "longitud": -86.58},
        {"Departamento": "Chontales", "linea1": 254, "linea2": 0, "latitud": 12.08, "longitud": -85.40},
        {"Departamento": "Río_San_Juan", "linea1": 278, "linea2": 0, "latitud": 11.13, "longitud": -84.78},
        {"Departamento": "Atlántico_Sur", "linea1": 257, "linea2": 0, "latitud": 12.00, "longitud": -83.75},
        {"Departamento": "Atlántico_Norte", "linea1": 258, "linea2": 0, "latitud": 14.05, "longitud": -83.38}
    ]
}

prefijos_internacionales = [
    ("Belice", 501),
    ("Guatemala", 502),
    ("El Salvador", 503),
    ("Honduras", 504),
    ("Costa Rica", 506),
    ("Panamá", 507),
    ("Estados Unidos", 1),
    ("España", 34)
]

regiones = {
    "Pacífico": {"departamentos": ["Managua","Carazo","Masaya","Granada","Rivas"], "troncal": "Troncal-Managua"},
    "Central": {"departamentos": ["Chontales","Boaco","Matagalpa","Jinotega"], "troncal": "Troncal-Matagalpa"},
    "Norte": {"departamentos": ["León","Chinandega","Estelí","Nueva_Segovia","Madriz","Río_San_Juan","Atlántico_Sur","Atlántico_Norte"], "troncal": "Troncal-ElRama"}
}

tarifas = {
    "local": {
        ("claro", "claro"): 0.016, ("tigo", "tigo"): 0.016,
        ("claro", "tigo"): 0.025, ("tigo", "claro"): 0.028,
        ("fijo", "fijo"): 0.0083, ("fijo", "claro"): 0.116,
        ("fijo", "tigo"): 0.116, ("tigo", "fijo"): 0.05, ("claro", "fijo"): 0.05
    },
    "interlocal": {
        ("claro", "claro"): 0.05, ("tigo", "tigo"): 0.05,
        ("claro", "tigo"): 0.07, ("tigo", "claro"): 0.075,
        ("fijo", "fijo"): 0.03, ("fijo", "claro"): 0.15,
        ("fijo", "tigo"): 0.15, ("tigo", "fijo"): 0.09, ("claro", "fijo"): 0.09
    },
    "internacional": {
        ("claro", "claro"): 0.20, ("tigo", "tigo"): 0.20,
        ("claro", "tigo"): 0.25, ("tigo", "claro"): 0.25,
        ("fijo", "fijo"): 0.15, ("fijo", "claro"): 0.30,
        ("fijo", "tigo"): 0.30, ("tigo", "fijo"): 0.28, ("claro", "fijo"): 0.28
    }
}

tarificacion = {
    "unidad": "segundos",
    "redondeo": True,
    "pulsos": {"duracion_pulso": 60, "costo_pulso": 0.05}
}
# ==========================================================

def determinar_operadora(numero: int):
    numero_str = str(numero)

    # >>> Claro
    for rango in prefijos_claro["rangos"]:
        if rango["inicio"] <= int(numero_str[:4]) <= rango["fin"]:
            return {"operadora_origen": "claro", "operadora_destino": "claro", "tipo": "local"}

    # >>> Tigo
    for rango in prefijos_tigo["rangos"]:
        if rango["inicio"] <= int(numero_str[:4]) <= rango["fin"]:
            return {"operadora_origen": "tigo", "operadora_destino": "tigo", "tipo": "local"}

    # >>> Fijos
    for rango in prefijos_fijos["rangos"]:
        if numero_str.startswith(str(rango["linea1"])) or numero_str.startswith(str(rango["linea2"])):
            departamento_origen = rango["Departamento"]
            tipo_llamada = "local"
            region = None
            troncal = None
            for reg_name, info in regiones.items():
                if departamento_origen in info["departamentos"]:
                    region = reg_name
                    troncal = info["troncal"]
            return {
                "operadora_origen": "fijo",
                "operadora_destino": "fijo",
                "tipo": tipo_llamada,
                "region": region,
                "troncal": troncal,
                "latitud": rango.get("latitud"),
                "longitud": rango.get("longitud")
            }

    # >>> Internacionales
    for pais, codigo in prefijos_internacionales:
        if numero_str.startswith(str(codigo)):
            return {"operadora_origen": "nacional", "operadora_destino": "internacional", "tipo": "internacional"}

    # >>> No identificado
    return {"operadora_origen": "desconocido", "operadora_destino": "desconocido", "tipo": "desconocido"}

def calcular_costo(tipo: str, operadora_origen: str, operadora_destino: str, duracion: int):
    # Obtener tarifa base según tipo y operadores
    tarifa_base = tarifas.get(tipo, {}).get((operadora_origen, operadora_destino), 0.10)

    duracion_pulso = tarificacion["pulsos"]["duracion_pulso"]
    costo_pulso = tarificacion["pulsos"]["costo_pulso"]

    if tarificacion.get("redondeo", False):
        pulsos = math.ceil(duracion / duracion_pulso)
    else:
        pulsos = duracion / duracion_pulso

    costo_total = pulsos * tarifas * (tarifa_base / costo_pulso)
    return round(costo_total, 4)
