from flask import Flask, request, jsonify
from flask_cors import CORS
from corazon_del_proyecto import determinar_operadora, calcular_costo
from base_datos import guardar_registro, generar_factura, listar_facturas
import sqlite3

app = Flask(__name__)
CORS(app)

@app.route("/procesar_llamada", methods=["POST"])
def procesar_llamada():
    datos = request.get_json()
    numero = datos.get("numero")
    duracion = datos.get("duracion", 0)

    info_llamada = determinar_operadora(numero)
    costo = calcular_costo(info_llamada["tipo"],
                           info_llamada["operadora_origen"],
                           info_llamada["operadora_destino"],
                           duracion)

    registro = {
        "numero": numero,
        "duracion": duracion,
        "operadora_origen": info_llamada["operadora_origen"],
        "operadora_destino": info_llamada["operadora_destino"],
        "tipo": info_llamada["tipo"],
        "costo": costo
    }
    guardar_registro(registro)

    response = {
        "numero": numero,
        "operadora": info_llamada["operadora_destino"],
        "tipo": info_llamada["tipo"],
        "costo": costo,
        "troncal": info_llamada.get("troncal", "--"),
        "latitud": info_llamada.get("latitud"),
        "longitud": info_llamada.get("longitud")
    }

    return jsonify(response)

#>>>>>>>>>>>>>>>>>>>>>>>>>>>.ingresar usuario

@app.route("/registrar_usuario", methods=["POST"])
def registrar_usuario():
    datos = request.get_json()
    nombre = datos.get("nombre")
    numero = datos.get("numero")
    region = datos.get("region")
    departamento = datos.get("departamento")
    operadora = datos.get("operadora")

    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO usuarios (nombre, numero, region, departamento, operadora)
            VALUES (?, ?, ?, ?, ?)
        """, (nombre, numero, region, departamento, operadora))
        conn.commit()
        return jsonify({"status": "ok", "mensaje": "Usuario registrado correctamente"})
    except sqlite3.IntegrityError:
        return jsonify({"status": "error", "mensaje": "El número ya existe"})
    finally:
        conn.close()

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>bloque reporte

@app.route("/usuarios", methods=["GET"])
def api_usuarios():
    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()
    cursor.execute("SELECT usuario_id, nombre, numero FROM usuarios")
    usuarios = [{"usuario_id": u[0], "nombre": u[1], "numero": u[2]} for u in cursor.fetchall()]
    conn.close()
    return jsonify(usuarios)

@app.route("/llamadas/<int:usuario_id>", methods=["GET"])
def api_llamadas_usuario(usuario_id):
    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT numero_llamado, duracion_s, operadora_origen, operadora_destino, troncal, costo
        FROM llamadas
        WHERE id_llamdas_usuario = ?
        ORDER BY fecha
    """, (usuario_id,))
    llamadas = [{
        "numero_llamado": r[0],
        "duracion_s": r[1],
        "operadora_origen": r[2],
        "operadora_destino": r[3],
        "troncal": r[4],
        "costo": r[5]
    } for r in cursor.fetchall()]
    conn.close()
    return jsonify(llamadas)


@app.route("/generar_factura", methods=["POST"])
def api_generar_factura():
    datos = request.get_json()
    usuario_id = datos.get("usuario_id")
    mes = datos.get("mes")

    generar_factura(usuario_id, mes)
    return jsonify({"status": "ok", "mensaje": "Factura generada"})


@app.route("/facturas/<int:usuario_id>", methods=["GET"])
def api_listar_facturas(usuario_id):
    facturas = listar_facturas(usuario_id)
    return jsonify([
        {"id_factura": f[0], "fecha_emision": f[1], "mes": f[2], "total": f[3]}
        for f in facturas
    ])

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<,,generar factura
@app.route("/usuarios/<int:usuario_id>", methods=["DELETE"])
def eliminar_usuario(usuario_id):
    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()

    # Primero borramos las llamadas asociadas
    cursor.execute("DELETE FROM llamadas WHERE id_llamdas_usuario = ?", (usuario_id,))

    # Luego borramos el usuario
    cursor.execute("DELETE FROM usuarios WHERE usuario_id = ?", (usuario_id,))
    conn.commit()
    conn.close()

    return jsonify({"mensaje": f"Usuario {usuario_id} eliminado correctamente"}), 200



if __name__ == "__main__":
    app.run(debug=True)
