import sqlite3
from datetime import datetime

# Crear tablas
conn = sqlite3.connect("telefonia.db")
cursor = conn.cursor()

# Tabla de usuarios
cursor.execute("""
CREATE TABLE IF NOT EXISTS usuarios (
    usuario_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    numero INTEGER UNIQUE NOT NULL,
    region TEXT NOT NULL,
    departamento TEXT NOT NULL,
    operadora TEXT NOT NULL
)
""")

# Tabla de llamadas
cursor.execute("""
CREATE TABLE IF NOT EXISTS llamadas (
    id_llamadas INTEGER PRIMARY KEY AUTOINCREMENT,
    id_llamdas_usuario INTEGER NOT NULL,
    numero_llamado INTEGER NOT NULL,
    region_origen TEXT NOT NULL,
    region_destino TEXT NOT NULL,
    tipo TEXT NOT NULL,
    operadora_origen TEXT NOT NULL,
    operadora_destino TEXT NOT NULL,
    troncal TEXT NOT NULL,
    duracion_s INTEGER NOT NULL,
    pulsos INTEGER NOT NULL,
    costo REAL NOT NULL,
    fecha TEXT NOT NULL,
    FOREIGN KEY (id_llamdas_usuario) REFERENCES usuarios(usuario_id)
)
""")

# Tabla de facturas
cursor.execute("""
CREATE TABLE IF NOT EXISTS facturas (
    id_factura INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL,
    fecha_emision TEXT NOT NULL,
    mes TEXT NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id)
)
""")


conn.commit()
conn.close()

print("Tablas creadas")

# Guardar registro de llamada
def guardar_registro(datos: dict):
    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO llamadas (
        id_llamdas_usuario, numero_llamado, region_origen, region_destino,
        tipo, operadora_origen, operadora_destino, troncal, duracion_s,
        pulsos, costo, fecha
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        1,  # usuario ficticio
        datos.get("numero"),
        datos.get("region_origen", "N/A"),
        datos.get("region_destino", "N/A"),
        datos.get("tipo"),
        datos.get("operadora_origen"),
        datos.get("operadora_destino"),
        datos.get("troncal", "N/A"),
        datos.get("duracion"),
        datos.get("pulsos", 0),
        datos.get("costo"),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))

    conn.commit()
    conn.close()
    print("Registro guardado")


def generar_factura(usuario_id: int, mes: str):

    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()

    # Obtener llamadas del mes
    cursor.execute("""
    SELECT SUM(costo) FROM llamadas
    WHERE id_llamdas_usuario = ?
    AND strftime('%Y-%m', fecha) = ?
    """, (usuario_id, mes))

    total = cursor.fetchone()[0] or 0.0

    # Insertar factura
    cursor.execute("""
    INSERT INTO facturas (usuario_id, fecha_emision, mes, total)
    VALUES (?, ?, ?, ?)
    """, (usuario_id, datetime.now().strftime("%Y-%m-%d"), mes, total))

    conn.commit()
    conn.close()

    print(f"Factura generada para usuario {usuario_id} ({mes}) → Total: {total:.2f} USD")

def listar_facturas(usuario_id: int):
    conn = sqlite3.connect("telefonia.db")
    cursor = conn.cursor()

    cursor.execute("""
    SELECT id_factura, fecha_emision, mes, total
    FROM facturas
    WHERE usuario_id = ?
    ORDER BY fecha_emision DESC
    """, (usuario_id,))
    facturas = cursor.fetchall()

    conn.close()
    return facturas

